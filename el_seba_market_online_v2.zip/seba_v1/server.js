const express = require('express');
const Database = require('better-sqlite3');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const crypto = require('crypto');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const USER = process.env.ADMIN_USER || 'sebamarket';
const PASS = process.env.ADMIN_PASS || 'acosta';
const db = new Database(process.env.DB_PATH || path.join(__dirname, 'el_seba_market.sqlite'));

db.exec(`CREATE TABLE IF NOT EXISTS app_state (id INTEGER PRIMARY KEY CHECK(id=1), data TEXT NOT NULL, updated_at INTEGER NOT NULL)`);
const getState = db.prepare('SELECT data, updated_at FROM app_state WHERE id=1');
const setState = db.prepare('INSERT INTO app_state(id,data,updated_at) VALUES(1,?,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data, updated_at=excluded.updated_at');

app.use(helmet({contentSecurityPolicy:false}));
app.use(cookieParser());
app.use(express.json({limit:'8mb'}));

const sessions = new Map();
function auth(req,res,next){
  const sid=req.cookies.esm_session;
  if(!sid || !sessions.has(sid)) return res.status(401).json({ok:false,error:'No autorizado'});
  const s=sessions.get(sid);
  if(Date.now()-s.created>7*24*60*60*1000){sessions.delete(sid);return res.status(401).json({ok:false,error:'Sesión vencida'});}
  next();
}

app.post('/api/login',(req,res)=>{
  const {user,pass}=req.body||{};
  if(user!==USER || pass!==PASS) return res.status(401).json({ok:false,error:'Usuario o contraseña incorrectos'});
  const sid=crypto.randomBytes(32).toString('hex');
  sessions.set(sid,{created:Date.now()});
  res.cookie('esm_session',sid,{httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production',maxAge:7*24*60*60*1000});
  res.json({ok:true});
});
app.post('/api/logout',(req,res)=>{ const sid=req.cookies.esm_session; if(sid)sessions.delete(sid); res.clearCookie('esm_session'); res.json({ok:true}); });
app.get('/api/me',auth,(req,res)=>res.json({ok:true,user:USER}));

app.get('/api/db',auth,(req,res)=>{
  const row=getState.get();
  if(!row) return res.json({ok:true,data:null,updatedAt:0});
  try { return res.json({ok:true,data:JSON.parse(row.data),updatedAt:row.updated_at}); }
  catch(e){ return res.status(500).json({ok:false,error:'Base de datos dañada'}); }
});

app.put('/api/db',auth,(req,res)=>{
  const data=req.body?.data;
  if(!data || typeof data!=='object') return res.status(400).json({ok:false,error:'Datos inválidos'});
  const now=Date.now();
  data._persistUpdatedAt=now;
  setState.run(JSON.stringify(data),now);
  res.json({ok:true,updatedAt:now});
});

app.get('/api/health',(req,res)=>res.json({ok:true,service:'El Seba Market',time:new Date().toISOString()}));
app.use(express.static(__dirname));
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'index.html')));
app.listen(PORT,()=>console.log(`El Seba Market online en puerto ${PORT}`));
