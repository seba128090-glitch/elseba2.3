# El Seba Market Online V2 — listo para desplegar

Esta versión toma la aplicación V11.2 y la prepara para un despliegue web real con Node.js, Express y SQLite persistente.

## Qué queda resuelto
- Aplicación web/PWA.
- API `/api/login`, `/api/db`, `/api/me`, `/api/logout` y `/api/health`.
- Sesión mediante cookie.
- Base de datos SQLite en servidor.
- Persistencia mediante disco cuando el proveedor lo soporta.
- Configuración `render.yaml` para despliegue directo en Render.
- Contraseña y usuario definidos como variables de entorno, no dentro del despliegue.

## Despliegue recomendado
1. Crear un servicio Web en Render desde este proyecto/repo.
2. Usar el `render.yaml` incluido.
3. Definir `ADMIN_USER` y `ADMIN_PASS` con valores propios.
4. Mantener el disco persistente montado en `/var/data`.
5. Esperar el build y abrir la URL HTTPS generada.
6. En Android, abrir la URL en Chrome y elegir instalar/agregar a pantalla de inicio.

## Importante
El servidor actual guarda el estado completo de la aplicación como un documento JSON dentro de SQLite. Es una transición práctica para esta etapa, pero para una operación con varios vendedores y mucho movimiento conviene migrar luego a tablas separadas y autenticación por usuario/rol.

## Credenciales
No se deben usar las credenciales de demostración anteriores en producción. Configurá `ADMIN_USER` y `ADMIN_PASS` en el proveedor de hosting.
